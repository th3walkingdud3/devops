# Vault Backend

To run locally, open a terminal at this repo's directory

# install required tooling
brew install pipenv
pipenv install flask flask-sqlalchemy


# start virtual environment
pipenv shell 

# env variables
export FLASK_APP=api
export FLASK_DEBUG=True

# run backend
flask run

# To deploy database (to kubernetes)
sh deploy-postgres.sh

# To populate database (using terminal and postman)
kubectl port-forward postgres-pod-name 5432

hit endpoint with GET request: http://127.0.0.1:5000/publish
