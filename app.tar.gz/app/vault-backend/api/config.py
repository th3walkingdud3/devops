import os

DB_URI = os.environ.get('DB_URI')
S3_BUCKET_NAME = os.environ.get('S3_BUCKET_NAME')
S3_BUCKET_KEY = os.environ.get('S3_BUCKET_KEY')
S3_BUCKET_SECRET_ACCESS_KEY = os.environ.get('S3_BUCKET_SECRET_ACCESS_KEY')