import React from 'react';
import styles from 'components/spatial/Tooltip.module.scss'

export default function VesselTooltip({ data }) {
  
  // **********************************
  // * Render
  // **********************************
  
  return (
    <div className={styles.container}>
      <span>Vessel name: {data.vesselName}</span>
      <span>Timestamp: {data.index}</span>
      <span>Status: {data.status}</span>
      <span>Speed: {data.speed}</span>
    </div>
  );
}