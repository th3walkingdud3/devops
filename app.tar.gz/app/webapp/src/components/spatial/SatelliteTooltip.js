import React from 'react';
import styles from 'components/spatial/Tooltip.module.scss'

export default function SatelliteTooltip({ data }) {
  
  // **********************************
  // * Render
  // **********************************
  
  return (
    <div className={styles.container}>
      <span>Satellite Number: {data.satNum}</span>
      <span>Timestamp: {data.index}</span>
      <span>Latitude: {data.lat}</span>
      <span>Longitude: {data.lon}</span>
    </div>
  );
}