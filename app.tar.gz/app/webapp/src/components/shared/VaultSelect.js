import React from 'react';
import Select from 'react-select';
import styles from 'components/shared/VaultSelect.module.scss';

export default function VaultSelect({ options, selected, onChange }) {
  
  // **********************************
  // * Members
  // **********************************
  
  function handleOnChange(option) {
    if (onChange) {
      onChange(option);
    }
  }

  // **********************************
  // * Render
  // **********************************

  return (
    <div className={styles.container}>
      <span>Satellites</span>
      <Select
        placeholder="Select Satellite"
        value={selected}
        onChange={handleOnChange}
        options={options}
      />
    </div>
  );
}