import './App.css';
import { HashRouter as Router, Route, NavLink } from 'react-router-dom';
import GlobeView from 'components/spatial/Globe/GlobeView';
import MapView from 'components/spatial/Map/MapView';
import ScatterMatrix from 'components/ScatterMatrix/ScatterMatrix';

const VIEWS = [
  { id: 0, path: '/globe', name: 'Globe', component: GlobeView },
  { id: 1, path: '/map', name: 'Map', component: MapView },
  { id: 2, path: '/3d-scatter-plot', name: '3D Scatter Plot', component: ScatterMatrix }
]

function Navbar() {
  return (
    <div className='navbar'>
      <NavLink key="landing" to="/">
        Vault
      </NavLink>
      <ul className='navlist'>
        {VIEWS.map((view, i) => (
          <li key={i + 1}>
            <NavLink
              key={view.id}
              to={view.path}
              title={view.name.charAt(0).toUpperCase() + view.name.slice(1)}
            >
              {view.name.charAt(0).toUpperCase() + view.name.slice(1)}
            </NavLink>
          </li>
        ))}
      </ul>
    </div>
  );
}

function Views() {
  return (
    <>
      {VIEWS.map((view, i) => (
        <Route
          key={i}
          path={view.path}
          component={view.component}
        />
      ))}
      <Route exact path="/" component={GlobeView} />
    </>
  )
}

function App() {
  return (
    <div className="App">
      <Router>
        <header className='app-header'>
          <Navbar />
        </header>
        <div className='app-body'>
          <Views />
        </div>
      </Router>
    </div>
  );
}

export default App;
