export const SATELLITE_NUMBERS = '/satellite-numbers';
export const SATELLITES_ROUTE = '/satellites';
export const VESSEL_NAMES = '/vessel-names';
export const VOYAGES_ROUTE = '/voyages';