import { getDistance } from 'geolib';

export const QUARTER_EARTH_CIRCUMFERENCE = 10018568.74;

export default function getNumberOfHits(satelliteCoordinates, shipCoordinates) {
  let hits = 0;
  shipCoordinates.forEach(coordinate => {
    if (getDistance(satelliteCoordinates, coordinate) <= QUARTER_EARTH_CIRCUMFERENCE) {
      hits++;
    }
  });
  return hits;
}