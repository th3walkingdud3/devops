import React, { useState, useMemo } from 'react';
import {getDistance} from 'geolib';
import ReactMapGL, { FlyToInterpolator, Popup } from 'react-map-gl';
import { DeckGL, ScatterplotLayer, ArcLayer } from 'deck.gl'
import { easeBackOut } from 'd3';
import { getFirstAndLastOfEach } from 'utils/transformData';
import { QUARTER_EARTH_CIRCUMFERENCE } from 'utils/getNumberOfHits';
import VesselTooltip from 'components/spatial/VesselTooltip';
import SatelliteTooltip from 'components/spatial/SatelliteTooltip';

export default function MapRenderer({ satellites, selectedSatellite, voyages }) {

  // **********************************
  // * Hooks & State
  // **********************************

  const [selectedMarker, setSelectedMarker] = useState(null);
  const [viewport, setViewport] = useState({
    latitude: 53.555014,
    longitude: -175.412146,
    zoom: 3,
    height: '100%',
    width: '100vw',
    transitionDuration: 2000,
    transitionInterpolator: new FlyToInterpolator()
  });

  const voyagePaths = useMemo(() => {
    const paths = Object.values(getFirstAndLastOfEach(voyages, 'imo', 'index'));
    return paths;
  }, [voyages])

  const allSatellitePaths = useMemo(() => {
    const input = satellites;
    const paths = Object.values(getFirstAndLastOfEach(input, 'satNum', 'index'));
    return paths;
  }, [satellites])

  const nonSelectedSatellitePaths = useMemo(() => {
    const input = selectedSatellite == null ? satellites : satellites.filter(element => selectedSatellite.satNum !== element.satNum);
    const paths = Object.values(getFirstAndLastOfEach(input, 'satNum', 'index'));
    return paths;
  }, [satellites, selectedSatellite])

  const selectedSatellitePath = useMemo(() => {
    const input =  selectedSatellite == null ? [] : satellites.filter(element => selectedSatellite.satNum === element.satNum);
    const paths = Object.values(getFirstAndLastOfEach(input, 'satNum', 'index'));
    return paths;
  }, [satellites, selectedSatellite]);

  const satelliteRange = useMemo(() => {
    if (selectedSatellite == null) {
      return [];
    }
    const matchingSatellites = satellites.filter(satellite => selectedSatellite.satNum === satellite.satNum)[0];
    return [matchingSatellites];
  }, [satellites, selectedSatellite])

  const satelliteCoordinate = useMemo(() => {
    if (selectedSatellite == null) {
      return null;
    }
    return { latitude: selectedSatellite.latitude, longitude: selectedSatellite.longitude };
  }, [selectedSatellite])

  const layers = [
    new ScatterplotLayer({
      id: 'scatterplot-layer-voyages',
      data: voyagePaths.flat(),
      getRadius: 10000, // radius in meters
      radiusMinPixels: 5,
      radiusMaxPixels: 30,
      getFillColor: (d) => {
        if (satelliteCoordinate == null) {
          return [255, 255, 255];
        }
        const coordinate = { latitude: d.latitude, longitude: d.longitude };
        return getDistance(satelliteCoordinate, coordinate) <= QUARTER_EARTH_CIRCUMFERENCE ? [97, 204, 88] : [255, 255, 255];
      },
      pickable: true,
      onClick: ({ object }) => {
        setViewport({ ...viewport, latitude: object.latitude, longitude: object.longitude })
        setSelectedMarker(object);
      },
      autoHighlight: true,
      transitions: {
        getRadius: {
          duration: 1000,
          easing: easeBackOut
        }
      }
    }),
    // new ArcLayer({
    //   id: 'arc-layer-voyages',
    //   data: voyagePaths,
    //   getSourcePosition: (d) => {
    //     return d[0].position
    //   },
    //   getTargetPosition: (d) => {
    //     return d[d.length-1].position
    //   },
    //   getSourceColor: [0, 255, 0],
    //   getTargetColor: [0, 0, 255],
    //   getWidth: 3,
    // }),
    new ScatterplotLayer({
      id: 'scatterplot-layer-satellites',
      data: allSatellitePaths.flat(),
      getRadius: 10000, // radius in meters
      radiusMinPixels: 5,
      radiusMaxPixels: 30,
      getFillColor: (d) => {
        return d.isDestination ? [237, 7, 65] : [255, 255, 255]
      },
      pickable: true,
      autoHighlight: true,
      onClick: ({ object }) => {  
        setViewport({ ...viewport, latitude: object.latitude, longitude: object.longitude })
        setSelectedMarker(object);
      },
    }),
    new ArcLayer({
      id: 'arc-layer-satellites',
      data: nonSelectedSatellitePaths,
      getSourcePosition: (d) => {
        return d[0].position
      },
      getTargetPosition: (d) => {
        return d[d.length-1].position
      },
      getSourceColor: (d) => { 
        return d.isDestination ? [237, 7, 65] : [190, 194, 203];
      },
      getTargetColor: (d) => { 
        return d.isDestination ? [237, 7, 65] : [190, 194, 203];
      },
      getWidth: 3,
    }),
    new ArcLayer({
      id: 'arc-layer-satellite-selected',
      data: selectedSatellitePath,
      getSourcePosition: (d) => {
        return d[0].position
      },
      getTargetPosition: (d) => {
        return d[d.length-1].position
      },
      getSourceColor: (d) => { 
        return d.isDestination ? [237, 7, 65] : [237, 7, 65];
      },
      getTargetColor: (d) => { 
        return d.isDestination ? [237, 7, 65] : [237, 7, 65];
      },
      getWidth: 3,
    }),
    new ScatterplotLayer({
      id: 'scatterplot-layer-satellite-ranges',
      data: satelliteRange,
      getRadius: QUARTER_EARTH_CIRCUMFERENCE,
      getFillColor: [255, 255, 255, 25]
    })
  ];
  // **********************************
  // * Render
  // **********************************

  return (
    <ReactMapGL
    {...viewport}
    mapboxApiAccessToken={process.env.REACT_APP_MAPBOX_TOKEN}
    mapStyle='mapbox://styles/kheiri/ckjagwhvi3r7b1ao0ir4i92qv'
    onViewportChange={viewport => {
        setViewport({ 
        ...viewport,
        zoom: Math.max(viewport.zoom, 2)
      });
    }}>
      <DeckGL viewState={viewport} layers={layers}/>
      {selectedMarker && (
        <Popup 
          latitude={selectedMarker.latitude}
          longitude={selectedMarker.longitude}
          onClose={() => setSelectedMarker(null)}>
            {selectedMarker.imo ? <VesselTooltip data={selectedMarker} /> : <SatelliteTooltip data={selectedMarker} /> }
        </Popup>
      )}
  </ReactMapGL>
  )
}