import React, { useState, useEffect, useCallback, useMemo } from 'react';
import styles from 'components/spatial/Map/Mapbox.module.scss';
import { VOYAGES_ROUTE, SATELLITES_ROUTE } from 'constants/routeConstants';
import VaultSlider from 'components/shared/VaultSlider';
import VaultSelect from 'components/shared/VaultSelect';
import { createDateTimeRange, uniquify, transformVoyageData, transformSatelliteData, getFirstAndLastOfEach, getFirstOfEach } from 'utils/transformData';
import HitDisplay from 'components/spatial/HitDisplay';
import MapRenderer from 'components/spatial/Map/MapRenderer';

export default function MapView() {

  // **********************************
  // * Hooks & State
  // **********************************

  const [voyageData, setVoyageData] = useState([]);
  const [satelliteData, setSatelliteData] = useState([]);
  const [selectedDay, setSelectedDay] = useState(1);
  const [selectedHour, setSelectedHour] = useState(1);
  const [selectedMinute, setSelectedMinute] = useState(0);
  const [selectedSatellite, setSelectedSatellite] = useState(null);
  
  // **********************************
  // * Members
  // **********************************

  const handleSatelliteOnChange = useCallback(satellite => {
    setSelectedSatellite(satellite);
  }, [])

  // **********************************
  // * Lifecycle
  // **********************************
  /**
   * Load voyage data
   */
  useEffect(() => {
    try {
      const dateTimeRange = createDateTimeRange(selectedDay, selectedHour, selectedMinute);
      fetch(VOYAGES_ROUTE, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ 
          startDateTime: dateTimeRange.startDateTime,
          endDateTime: dateTimeRange.endDateTime
        })
      }).then(response => response.json().then(jsonData => {
        if (response.ok) {
          setVoyageData(jsonData);
        }
      }))
    } catch(e) {
      console.error('Error loading voyage data' + e);
    }
  }, [selectedDay, selectedHour, selectedMinute])

  /**
   * Load satellite data
   */
  useEffect(() => {
    try {
      const dateTimeRange = createDateTimeRange(selectedDay, selectedHour, selectedMinute);
      fetch(SATELLITES_ROUTE, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          startDateTime: dateTimeRange.startDateTime,
          endDateTime: dateTimeRange.endDateTime
        })
      }).then(response => response.json().then(jsonData => {
        if (response.ok) {
          setSatelliteData(jsonData);
        }
      }))
    } catch (e) {
      console.error('Error Loading Satellite data' + e)
    }
  }, [selectedDay, selectedHour, selectedMinute])

  const satellites = useMemo(() => {
    const transformed = Object.values(getFirstAndLastOfEach(transformSatelliteData(satelliteData), 'satNum', 'index')).flat();
    return transformed;
  }, [satelliteData])

  const selectedSatellitePath = useMemo(() => {
    if (selectedSatellite && selectedSatellite.value) {
      const path = satellites.filter(element => selectedSatellite.value.satNum === element.satNum);
      return path;
    } else {
      return [];
    }
  }, [selectedSatellite, satellites])

  const voyages = useMemo(() => {
    const transformed = Object.values(getFirstOfEach(transformVoyageData(voyageData), 'imo', 'index')).flat();
    return transformed;;
  }, [voyageData])

  const voyageStartPoints = useMemo(() => {
    const paths = Object.values(getFirstAndLastOfEach(voyages, 'imo', 'index'));
    return paths.map(path => path[0]);
  }, [voyages])

  const satelliteOptions = useMemo(() => {
    const options = uniquify(satellites, 'satNum').map(element => { 
      return { label: element.satNum, value: element };
    });
    if (selectedSatellite && selectedSatellite.value != null) {
      const hasSelectedSatellite = satellites.some(element => selectedSatellite.value.satNum === element.satNum);
      if (!hasSelectedSatellite) {
        setSelectedSatellite(null);
      }
    }
    return options;
  }, [selectedSatellite, satellites])

  // **********************************
  // * Render
  // **********************************

  return (
    <div className={styles.container}>
      <div className={styles.containerHeader}>
        <div className={styles.selectContainer}>
          <VaultSelect options={satelliteOptions} labelKey='satNum' selected={selectedSatellite} onChange={handleSatelliteOnChange} />
        </div>
        <div className={styles.sliderContainer}>
          <VaultSlider
            label='Day'
            value={selectedDay}
            axis="x"
            xstep={1}
            xmin={1}
            xmax={31}
            x={selectedDay}
            onChange={({ x }) => {
              setSelectedDay(parseInt(x.toFixed(0)))
            }}
          />
          <VaultSlider
            label='hour'
            value={selectedHour}
            axis="x"
            xstep={1}
            xmin={0}
            xmax={23}
            x={selectedHour}
            onChange={({ x }) => {
              setSelectedHour(parseInt(x.toFixed(0)))
            }}
          />
          <VaultSlider
            label='minute'
            value={selectedMinute}
            axis="x"
            xstep={5}
            xmin={0}
            xmax={55}
            x={selectedMinute}
            onChange={({ x }) => {
              setSelectedMinute(parseInt(x.toFixed(0)))
            }}
          />
        </div>
        <HitDisplay label='Hits at start of interval: ' selectedSatellite={selectedSatellitePath[0]} ships={voyageStartPoints} />
      </div>
      <div className={styles.mapContainer}>
       <MapRenderer selectedSatellite={selectedSatellite && selectedSatellite.value} satellites={satellites} voyages={voyages} />
      </div>
    </div>
    
  );
}