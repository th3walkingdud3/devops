import React, { useMemo } from 'react';
import getNumberOfHits from 'utils/getNumberOfHits';
import styles from 'components/spatial/HitDisplay.module.scss';

export default function HitDisplay({ label, selectedSatellite, ships }) {
  
  const satelliteCoordinates = useMemo(() => {
    if (selectedSatellite == null) {
      return null;
    }
    return { latitude: selectedSatellite.latitude, longitude: selectedSatellite.longitude };
  }, [selectedSatellite]);

  const shipCoordinates = useMemo(() => {
    return ships.map(data => ({ latitude: data.latitude, longitude: data.longitude }));
  }, [ships])

  // **********************************
  // * Render
  // **********************************
  
  return (
    <div className={styles.container}>
      <span>
        {label} {satelliteCoordinates == null ? 'No satellite selected' :  getNumberOfHits(satelliteCoordinates, shipCoordinates) }
      </span>
    </div>
  );
}