import React, { useMemo } from 'react';
import { getDistance } from 'geolib';
import {QUARTER_EARTH_CIRCUMFERENCE} from 'utils/getNumberOfHits';
import Globe from 'react-globe.gl';
import { Mesh, SphereBufferGeometry, MeshLambertMaterial } from 'three';

export default function GlobeRenderer({ selectedSatellite, satellites, voyages }) {
  
  const satelliteCoordinate = useMemo(() => {
    if (selectedSatellite == null) {
      return null;
    }
    return { latitude: selectedSatellite.latitude, longitude: selectedSatellite.longitude };
  }, [selectedSatellite])

  // **********************************
  // * Render
  // **********************************

  return (
    <Globe
      globeImageUrl="//unpkg.com/three-globe/example/img/earth-night.jpg"

      // points
      pointsData={voyages}
      pointsMerge={false}
      pointColor={(point) => {
        if (satelliteCoordinate == null) {
          return '#fff';
        }
        const coordinate = { latitude: point.latitude, longitude: point.longitude };
        return getDistance(satelliteCoordinate, coordinate) <= QUARTER_EARTH_CIRCUMFERENCE ? '#62cc58' : '#fff';
      }}
      pointAltitude={0.01}
      pointRadius={0.15}
      onPointClick={() => {}}

      // arcs
      // arcsData={voyageRoutes}
      // arcLabel={d => `${d.vesselName}`}
      // arcStartLat={d => d.srcLocation.lat}
      // arcStartLng={d => d.srcLocation.lng}
      // arcEndLat={d => d.destLocation.lat}
      // arcEndLng={d => d.destLocation.lng}
      // arcDashLength={0.4}
      // arcDashGap={0.2}
      // arcDashAnimateTime={1500}
      // arcsTransitionDuration={0}
      // arcAltitude={0.3}
      // arcColor={d => {
      //   return [`rgba(255, 255, 255, ${1})`, `rgba(255, 255, 255, ${1})`];
      // }}
      // arcStroke={0.075}

      // custom layer (satellites)
      // customLayerData={satellites}
      // customThreeObject={d => new Mesh(
      //   new SphereBufferGeometry(d.radius),
      //   new MeshLambertMaterial({ color: d.color })
      // )}
      // customThreeObjectUpdate={(obj, d) => {
      //   obj.position.x = d.lat;
      //   obj.position.y = d.lon;
      //   obj.position.z = 1;
      // }}
      // onCustomLayerClick={(obj, event) => {
        
      // }}
    /> 
  )
}