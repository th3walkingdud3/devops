import {React, useEffect, useState, useRef} from 'react';
import Select from 'react-select';
import Plot from 'react-plotly.js';
import moment from 'moment';
import TEST_DATA from 'data/AIS_2015_01_Zone01.json';
import { VOYAGES_ROUTE, VESSEL_NAMES, SATELLITES_ROUTE } from 'constants/routeConstants';
import hashStringToColor from 'utils/hashStringToColor';


export default function ScatterMatrix() {

//x lat (static scale)
//y lon (static scale)
//z time (5 min increments)
//date picker to pick (filter) the day
//red color markers = exact data
//orange color markers = interpolated data

  /************************
   *        FIELDS        *
   ************************/

  const [xArr, setXArr] = useState(null);
  const [yArr, setYArr] = useState(null);
  const [zArr, setZArr] = useState(null);
  const [colors, setColors] = useState(null);
  const [satData, setSatData] = useState(null);
  const [realData, setRealData] = useState(null);
  const [preparedData, setPreparedData] = useState(null);
  const [zAxisRange, setZAxisRange] = useState(null);
  const [satOptions, setSatOptions] = useState([]);
  const [selectedSatellite, setSelectedSatellite] = useState([]);
  const [dateOptions, setDateOptions] = useState([]);
  const [selectedDate, setSelectedDate] = useState(null);
  const _isMounted = useRef(false);


  // const preparedData = TEST_DATA.map(element => ({
  //   x: element['LAT'],
  //   y: element['LON'],
  //   z: moment(element['BaseDateTime'], 'YYYY-MM-DDThh:mm:ss')
  // }))

  /************************
   *    EVENT HANDLERS    *
   ************************/

  function handleDateSelect(selectedDate) {
    setSelectedDate(selectedDate);

    let beginMoment = moment(selectedDate.value);
    let endMoment = beginMoment.clone();
    endMoment.add(24, "hours");
    
    let newData = filterDataBetweenDates(preparedData, beginMoment, endMoment);
    let x = newData.map(element => element.x);
    let y = newData.map(element => element.y);
    let z = newData.map(element => element.z.toDate());
    let colors = newData.map(element => hashStringToColor(element.name));
    setZAxisRange([beginMoment.toDate(), endMoment.toDate()]);
    setXArr(x);
    setYArr(y);
    setZArr(z);
    setColors(colors);
  }

  function handleSatelliteSelect(selectedSatellite) {

  }

  /************************
   *    HELPER METHODS    *
   ************************/

  function filterDataBetweenDates(data, beginMoment, endMoment) {
    return data.filter(element => {
      return element.z.isBetween(
        beginMoment,
        endMoment
      )
    })
  }

  function transform(data) {
    return data.map(element => ({
      x: Number.parseFloat(element.lat),
      y: Number.parseFloat(element.lon),
      z: moment(element.index, 'YYYY-MM-DD hh:mm:ss'),
      name: element.vesselName
    }));
  }

  /************************
   *      LIFECYCLE       *
   ************************/
  
  useEffect(() => {
    _isMounted.current = true;

    if(preparedData) {

      let allDates = preparedData.map(element => element.z.format('YYYY-MM-DD'));
      let dateSet = [...new Set(allDates)];
      let dateOptions = dateSet.map(element => ({'value': element, 'label': element}));

      let allSats = preparedData.map(element => element["satNum"]);
      let satSet = [...new Set(allSats)];
      let satOptions = satSet.map(element => ({'value': element, 'label': element}));

      if(_isMounted.current) {
        setDateOptions(dateOptions);
        setSatOptions(satOptions);
      }
    }

    return function cleanup() {
      _isMounted.current = false;
    };
  }, [preparedData]);

  useEffect(() => {
    if(realData) {
      setPreparedData(transform(realData));
    }
  }, [realData]);

  useEffect(() => {
    fetch(VOYAGES_ROUTE, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({"satNum": []})
    }).then(response => response.json().then(jsonData => {
      if (response.ok) {
        setRealData(jsonData);
      }
    }))
    // fetch(SATELLITES_ROUTE, {
    //   method: 'POST',
    //   headers: {
    //     'Content-Type': 'application/json'
    //   },
    //   body: JSON.stringify({"satNum": []})
    // }).then(response => response.json().then(jsonData => {
    //   if (response.ok) {
    //     setSatData(jsonData);
    //   }
    // }))
  }, [])

  /************************
   *        RENDER        *
   ************************/

  return <>
  <div className="scatter-container">
    <div className="scatter-selects">
      <div className="date-select">
        <Select
            placeholder="Select Date..."
            value={selectedDate}
            onChange={handleDateSelect}
            options={dateOptions}
          />
      </div>
      <div className="sat-select">
        <Select
            placeholder="Select Satellite..."
            value={selectedSatellite}
            onChange={handleSatelliteSelect}
            options={satOptions}
          />
      </div>
    </div>

    {(realData == null) ? 
      <>
      <div className="loading-container">
        <h2>Loading Data...</h2>
      </div>
      </>
      :
      <>
        <Plot
            data={[
              {
                x: xArr,
                y: yArr,
                z: zArr,
                type: 'scatter3d',
                mode: 'markers',
                marker: {color: colors, size: '3'},
              }
            ]}
            layout= {{
              width: 900, 
              height: 700, 
              paper_bgcolor:"#354d42",
              scene: {
                aspectmode: "manual",
                aspectratio: {
                  'x': 1,
                  'y': 1,
                  'z': 1,
                },
                xaxis: {
                  color: "white"
                },
                yaxis: {
                  color: "white"
                },
                zaxis: {
                  color: "white",
                  type: 'date',
                  nticks: 10,
                  range: zAxisRange,
                }
              }
            }}
          />
        </>
      }
    
    
  </div>
  
  </>;
}