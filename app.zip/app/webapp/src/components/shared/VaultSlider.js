import React from 'react';
import styles from 'components/shared/VaultSlider.module.scss'
import Slider from 'react-input-slider'

export default function VaultSlider({ axis, label, value, onChange, x, xmin, xmax, xstep }) {
  return (
    <div className={styles.slider}>
      <span>{`${label}: ${value}`}</span>
      <Slider
        axis={axis}
        xstep={xstep}
        xmin={xmin}
        xmax={xmax}
        x={x}
        onChange={onChange}
      />
    </div>
  )
}