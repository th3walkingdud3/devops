import moment from 'moment'; 

// TODO: fix backend so that we dont have to do this string stuff

export function createDateTimeRange(day, hour, minute) {
  const dayStr = day < 10 ? `0${day}` : day.toString();
  const hourStr = hour < 10 ? `0${hour}` : hour.toString();
  const minuteStr = minute < 10 ? `0${minute}` : minute.toString();
  let lowerBoundStr = `2017-01-${dayStr}T${hourStr}:${minuteStr}:00`;
  let upperBoundStr = moment(lowerBoundStr).add(5, 'minutes').format('YYYY-MM-DDThh:mm:ss');
  return {
    startDateTime: lowerBoundStr,
    endDateTime: upperBoundStr
  }
}

export function getFirstOfEach(data, bucketKey, sortKey) {
  function comparator(a, b) {
    if (a[sortKey] < b[sortKey]) {
      return -1;
    }
    if (a[sortKey] > b[sortKey]) {
      return 1;
    }
    return 0;
  }
  const slots = {};
  const sorted = data.sort(comparator);
  sorted.forEach(element => {
    if (slots[element[bucketKey]] == null) {
      slots[element[bucketKey]] = element;
    }
  })
  return Object.values(slots);
}

export function getFirstAndLastOfEach(data, bucketKey, sortKey) {
  function comparator(a, b) {
    if (a[sortKey] < b[sortKey]) {
      return -1;
    }
    if (a[sortKey] > b[sortKey]) {
      return 1;
    }
    return 0;
  }

  const buckets = {};
  data.forEach(element => {
    if (buckets[element[bucketKey]] == null) {
      buckets[element[bucketKey]] = [element];
    } else {
      buckets[element[bucketKey]].push(element);
    }
  });
  Object.keys(buckets).forEach(key => {
    const sorted = buckets[key].sort(comparator);
    sorted[0].isDestination = false;
    sorted[sorted.length-1].isDestination = true;
    buckets[key] = [sorted[0], sorted[sorted.length-1]];
  });
  return buckets;
}

export function uniquify(data, key) {
  function onlyUnique(value, index) {
    return data.findIndex(element => element[key] === value[key]) === index;
  }
  return data.filter(onlyUnique);
}

export function transformVoyageData(data) {
  return data.map(element => ({
    key: element.imo,
    imo: element.imo,
    vesselName: element.vesselName,
    lat: Number.parseFloat(element.lat),
    lon: Number.parseFloat(element.lon),
    lng: Number.parseFloat(element.lon),
    latitude: Number.parseFloat(element.lat),
    longitude: Number.parseFloat(element.lon),
    position: [Number.parseFloat(element.lon), Number.parseFloat(element.lat)],
    index: element.index,
    status: element.status,
    speed: element.speed,
    distance: element.distance,
  }));
}

export function transformSatelliteData(data) {
  return data.map(element => ({
    key: element.satNum,
    satNum: element.satNum,
    lat: Number.parseFloat(element.lat),
    lon: Number.parseFloat(element.lon),
    lng: Number.parseFloat(element.lon),
    latitude: Number.parseFloat(element.lat),
    longitude: Number.parseFloat(element.lon),
    position: [Number.parseFloat(element.lon), Number.parseFloat(element.lat)],
    index: element.index  
  }));
}
