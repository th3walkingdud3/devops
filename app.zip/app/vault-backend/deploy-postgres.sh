# Default postgresUsername="postgres" is admin
# Default port is 5432
helm install vault-postgresql \
  --set postgresqlPassword=password,postgresqlDatabase=vault-db \
    bitnami/postgresql