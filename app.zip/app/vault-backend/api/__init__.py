import os
import os.path
from os import path
from flask import Flask, Blueprint, jsonify, current_app as app, request, Response, make_response
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import and_
from .config import S3_BUCKET_NAME, S3_BUCKET_KEY, S3_BUCKET_SECRET_ACCESS_KEY, DB_URI
from .models import Voyage, Satellite
import boto3
import json
import csv
from flask.json import JSONEncoder

###############################
# Helper Functions
###############################

def loadFromS3(objectName, path, bucketName=S3_BUCKET_NAME):
    print('1')
    if not os.path.exists(path):
        print(S3_BUCKET_NAME)
        print(S3_BUCKET_KEY)
        print(S3_BUCKET_SECRET_ACCESS_KEY)
        s3 = boto3.client('s3', aws_access_key_id=S3_BUCKET_KEY, aws_secret_access_key=S3_BUCKET_SECRET_ACCESS_KEY)
        print(s3)
        f = s3.download_file(bucketName, objectName, path)
        print(f)


def jsonifyFile(inputPath, outputPath):
    if not os.path.exists(outputPath):
        data = []
        with open(inputPath) as inputFile:
            reader = csv.DictReader(inputFile)
            for row in reader:
                data.append(row)
        with open(outputPath, 'w') as jsonFile:
            jsonFile.write(json.dumps(data, indent=2))

# loads json files from the static/data directory
def loadJsonFile(fileName):
    data = []
    with open(os.path.join('static', 'data', fileName)) as f:
        jsonData = f.read()
        data = json.loads(jsonData)
    return data

def create_app():
    # loadFromS3('processed/ais/all_voyages_2017.csv', 'static/data/all_voyages_2017.csv')
    # loadFromS3('Raw/TLE/cleaned/top20_sat_5min_Jan2017.json', 'static/data/top20_sat_5min_Jan2017.json', 'af-vault')
    jsonifyFile('static/data/all_voyages_2017.csv', 'static/data/all_voyages_2017.json')
    return app

###############################
# Global vars
###############################
app = Flask(__name__)
app = create_app()
app.config['SQLALCHEMY_DATABASE_URI'] = DB_URI
db = SQLAlchemy(app)

###############################
# Data Routes
###############################

@app.route('/vessel-names', methods=['GET'])
def vesselNames():
    data = db.session.query(Voyage.vesselName).distinct().all()
    return jsonify(data)

@app.route('/satellite-numbers', methods=['GET'])
def satelliteNumbers():
    data = db.session.query(Satellite.satNum).distinct().all()
    return jsonify(data)

@app.route('/voyages', methods=['POST'])
def voyages():
    jsonRequest = request.get_json()
    query = Voyage.query
    if 'vesselName' in jsonRequest:
        query = query.filter(Voyage.vesselName.in_(jsonRequest['vesselName']))
    if 'startDateTime' in jsonRequest and 'endDateTime' in jsonRequest:
        query = query.filter(and_(Voyage.index >= jsonRequest['startDateTime'], Voyage.index <= jsonRequest['endDateTime']))
    data = query.all()
    return jsonify(data)

@app.route('/satellites', methods=['POST'])
def satellites():
    jsonRequest = request.get_json()
    query = Satellite.query
    if 'satNum' in jsonRequest:
        query = query.filter(Satellite.satNum.in_(jsonRequest['satNum']))
    if 'startDateTime' in jsonRequest and 'endDateTime' in jsonRequest:
        query = query.filter(and_(Satellite.index >= jsonRequest['startDateTime'], Satellite.index <= jsonRequest['endDateTime']))
    data = query.all()
    return jsonify(data)

@app.route('/publish')
def publish():
    voyagesJson = loadJsonFile('all_voyages_2017.json')
    satellitesJson = loadJsonFile('top20_sat_5min_Jan2017.json')

    for obj in satellitesJson:
        time = obj['TimeStamp'][:-10]
        satellite = Satellite(obj['SatNum'], time, obj['lat'], obj['lon'], obj['level_1'])
        db.session.add(satellite)
    db.session.commit()
    print('Published satellites')

    for obj in voyagesJson:
        index = list(obj['index'])
        index[10] = 'T'
        index = "".join(index)
        voyage = Voyage(index, obj['MMSI'], obj['LAT'], obj['LON'], obj['SOG'], obj['COG'], obj['Heading'], obj['VesselName'], obj['IMO'], obj['CallSign'], obj['VesselType'], obj['Status'], obj['Length'], obj['Width'], obj['Draft'], obj['Cargo'], obj['tvalue'], obj['delta'], obj['voyage_no'], obj['LAT_rad'], obj['LON_rad'], obj['distance'], obj['speed'])
        db.session.add(voyage)
    db.session.commit()
    print('Published voyages')
    print('Finished publishing entries')
    return make_response('200')

@app.route('/create-all')
def createAll():
    from .models import db
    db.create_all()
    return make_response('200')

@app.route('/drop-all')
def dropAll():
    from .models import db
    db.drop_all()
    return make_response('200')





