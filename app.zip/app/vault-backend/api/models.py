from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import validates
from dataclasses import dataclass
from .config import DB_URI

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = DB_URI
db = SQLAlchemy(app)

@dataclass
class Voyage(db.Model):
    id: int = db.Column(db.Integer, primary_key=True)
    index: str = db.Column(db.String(), unique=False, nullable=True)
    mmsi: str = db.Column(db.String(), unique=False, nullable=True)
    lat: str = db.Column(db.String(), unique=False, nullable=True)
    lon: str = db.Column(db.String(), unique=False, nullable=True)
    sog: str = db.Column(db.String(), unique=False, nullable=True)
    cog: str = db.Column(db.String(), unique=False, nullable=True)
    heading: str = db.Column(db.String(), unique=False, nullable=True)
    vesselName: str = db.Column(db.String(), unique=False, nullable=True)
    imo: str = db.Column(db.String(), unique=False, nullable=True)
    callSign: str = db.Column(db.String(), unique=False, nullable=True)
    vesselType: str = db.Column(db.String(), unique=False, nullable=True)
    status: str = db.Column(db.String(), unique=False, nullable=True)
    length: str = db.Column(db.String(), unique=False, nullable=True)
    width: str = db.Column(db.String(), unique=False, nullable=True)
    draft: str = db.Column(db.String(), unique=False, nullable=True)
    cargo: str = db.Column(db.String(), unique=False, nullable=True)
    tvalue: str = db.Column(db.String, unique=False, nullable=True)
    delta: str = db.Column(db.String(), unique=False, nullable=True)
    voyageNo: str = db.Column(db.String(), unique=False, nullable=True)
    latRad: str = db.Column(db.String(), unique=False, nullable=True)
    lonRad: str = db.Column(db.String(), unique=False, nullable=True)
    distance: str = db.Column(db.String(), unique=False, nullable=True)
    speed: str = db.Column(db.String(), unique=False, nullable=True)
    
    def __init__(self, index, mmsi, lat, lon, sog, cog, heading, vesselName, imo, callSign, vesselType, status, length, width, draft, cargo, tvalue, delta, voyageNo, latRad, lonRad, distance, speed):
        self.index = index
        self.mmsi = mmsi
        self.lat = lat
        self.lon = lon
        self.sog = sog
        self.cog = cog
        self.heading = heading
        self.vesselName = vesselName
        self.imo = imo
        self.callSign = callSign
        self.vesselType = vesselType
        self.status = status
        self.length = length
        self.width = width
        self.draft = draft
        self.cargo = cargo
        self.tvalue = tvalue
        self.delta = delta
        self.voyageNo = voyageNo
        self.latRad = latRad
        self.lonRad = lonRad
        self.distance = distance
        self.speed = speed
    
    def __repr__(self):
        return '<Voyage %r>' % self.id

@dataclass
class Satellite(db.Model):
    id: int = db.Column(db.Integer, primary_key=True)
    satNum: str = db.Column(db.String(), unique=False, nullable=True)
    index: str = db.Column(db.String(), unique=False, nullable=True)
    lat: str = db.Column(db.String(), unique=False, nullable=True)
    lon: str = db.Column(db.String(), unique=False, nullable=True)
    level1: str = db.Column(db.String(), unique=False, nullable=True)

    def __init__(self, satNum, index, lat, lon, level1):
        self.satNum = satNum
        self.index = index
        self.lat = lat
        self.lon = lon
        self.level1 = level1
    
    def __repr__(self):
        return '<Satellite %r>' % self.id